from django.conf import settings


def site(request):
    return {"owner": settings.SITE_OWNER}

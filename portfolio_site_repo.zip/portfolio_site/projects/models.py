from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Project(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True)
    summary = models.CharField(max_length=200, help_text="One line shown on the card.")
    description = models.TextField(help_text="What it does and what you built.")
    image = models.ImageField(upload_to="projects/", blank=True)
    tech_stack = models.CharField(max_length=200, help_text="Comma separated, e.g. Django, PostgreSQL")
    github_url = models.URLField(blank=True)
    live_url = models.URLField(blank=True)
    featured = models.BooleanField(default=False, help_text="Show on the home page.")
    order = models.PositiveIntegerField(default=0, help_text="Lower numbers come first.")
    created = models.DateField(auto_now_add=True)

    class Meta:
        ordering = ["order", "-created"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("projects:detail", args=[self.slug])

    @property
    def tech_list(self):
        return [t.strip() for t in self.tech_stack.split(",") if t.strip()]

    def __str__(self):
        return self.title

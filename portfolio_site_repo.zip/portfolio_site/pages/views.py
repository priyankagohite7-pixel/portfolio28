from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from django.shortcuts import redirect, render

from projects.models import Project
from .forms import ContactForm


def home(request):
    featured = Project.objects.filter(featured=True)[:3]
    return render(request, "pages/home.html", {"featured": featured})


def about(request):
    # Edit these lists, or move them to models later if you want admin control.
    skills = {
        "Backend": ["Python", "Django", "Django REST Framework", "PostgreSQL"],
        "Frontend": ["HTML", "CSS", "Bootstrap", "JavaScript"],
        "Tools": ["Git", "Docker", "Linux", "Render / Railway"],
    }
    return render(request, "pages/about.html", {"skills": skills})


def contact(request):
    form = ContactForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        msg = form.save()
        try:
            send_mail(
                subject=f"Portfolio message from {msg.name}",
                message=f"{msg.message}\n\nReply to: {msg.email}",
                from_email=settings.EMAIL_HOST_USER or settings.CONTACT_RECIPIENT,
                recipient_list=[settings.CONTACT_RECIPIENT],
            )
        except Exception:
            pass  # The message is already saved in the database.
        messages.success(request, "Thanks, your message is in. I'll reply by email.")
        return redirect("contact")
    return render(request, "pages/contact.html", {"form": form})

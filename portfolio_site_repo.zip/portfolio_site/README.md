# Django Portfolio (Bootstrap)

## Run locally

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations pages projects
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000 and add projects at http://127.0.0.1:8000/admin.
Tick "Featured" on up to three projects to show them on the home page.

## Personalise

1. Edit `SITE_OWNER` in `config/settings.py` (name, role, links).
2. Edit the skills list in `pages/views.py` and the text in `templates/pages/about.html`.
3. Put your resume at `static/resume.pdf` and change the link in `about.html` to `{% static 'resume.pdf' %}`.
4. Change colours in the `:root` block of `static/css/style.css`.

## Contact form email

By default emails print in the terminal. For real email, set environment variables:
`EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend`, `EMAIL_HOST_USER`,
`EMAIL_HOST_PASSWORD` (Gmail needs an app password), and `CONTACT_RECIPIENT`.
Messages are always saved in the admin under "Contact messages".

## Deploy (Render / Railway)

Set `DEBUG=0`, `SECRET_KEY`, and `ALLOWED_HOSTS`. Build command:
`pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate`
Start command: `gunicorn config.wsgi`.
Uploaded images need persistent storage in production (a Render disk, or Cloudinary/S3).
